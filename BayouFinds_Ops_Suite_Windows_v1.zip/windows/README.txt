BayouFinds Ops Suite — Windows

Overview
--------
Menu-driven audit and operations toolkit for Windows environments.

Requirements
------------
- PowerShell 7 (pwsh) recommended
- Active Directory module (for AD-related reports)
- Appropriate permissions for target environment

Quick Start
-----------
1) Open PowerShell
2) cd into this folder
3) Run:
   pwsh -File run-windows.ps1

Key Features
------------
- SOX Audit Runner (Full Evidence Pack)
- Access Snapshot Export / Restore
- AD User & Role Audits
- Privileged Group Audit
- Password Policy Audit
- Inactive Users Audit
- Local Admin Audit
- Patch Dump
- Mapped Drives Report
- Password Reset Generator

Notes
-----
- Some AD scripts require domain connectivity.
- Review outputs in the 'output' folder before sharing.

Support
-------
support@bayoufinds.com
https://bayoufinds.com
